<!DOCTYPE html>
<html>
<head>
	<title>Data</title>
</head>
<style type="text/css">
	body{
		background-color: pink;
	}
	header{
		background-color: black;
		color: white;
		padding: 20px;
		text-align: center;
		font-size: 30px;
	}
	p{
		text-align: center;
		font-size: 35px;
		font-family: sans-serif;
	}
</style>
<body>
	<header>Data Information</header>
	<br>
	<p>
		Hi! Good Day!
		<br>
		Im <?php echo e($dfname); ?> <?php echo e($dlname); ?> . If you have any questions here's my contact number <?php echo e($dcpno); ?>

		<br>
		By the way I'm <?php echo e($dgender); ?> . And I have no intention to hurt/harm you.
		<br>
		My motto in life is: <?php echo e($dmotto); ?>

		</p>
</body>
</html><?php /**PATH C:\Users\Jewel Joyce Ramos\Desktop\laravel\laravel\resources\views/data.blade.php ENDPATH**/ ?>