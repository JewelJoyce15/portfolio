<!DOCTYPE html>
<html>
<head>
	<title>Portfolio</title>
</head>
<style type="text/css">
	*{
		margin: 0px;
	}
	body{
		background-image: url("/pics/pic1.jpg");
	}
	header{
			background-color: #ECC9C7;
			padding: 10px;
			color: black;
			text-align: center;
			font-size: 25px;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #cf7956;

	}
	.nav{
		text-decoration: none;
		font-size: 20px;
		font-family: sans-serif;
		color: #2E3047;
	}
	.pic{
		height: 300px;
		width: 250px;
		margin-top: 1px;
		margin-left: 650px;
	}
	.socmed{
		text-align: center;
	}
	footer{
		padding: 20px;
		background-color: black;
		margin-top: 50px;
		color: white;
		text-align: center;
	}
</style>
<body>
<header>Dreams of Jewel Joyce</header>
<br>
<nav>
	<a href="home.php" class="nav">Home</a>
	<a href="about.php" class="nav">About</a>
	<a href="contact.php" class="nav">Contact</a>
</nav>
<br>
<div>
	<img src="/pics/je.jpg" class="pic">
</div>
<div class="socmed">
	<p>Facebook</p>
	<p>Jewel Joyce Ramos</p>
	<br>
	<p>Gmail</p>
	<p>ayinjerovi@gmail.com</p>
	<br>
	<p>Twitter</p>
	<p>@RamosJewelJoyce</p>
</div>
<footer>Ramos &copy; 2020</footer>
</body>
</html>