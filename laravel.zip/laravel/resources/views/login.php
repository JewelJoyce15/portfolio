<!DOCTYPE html>
<html>
<head>
	<title>Barangay Health Center</title>
</head>
<style type="text/css">
	
</style>
<body>
<div class="header">
	<h2>Register</h2>
</div>
	<form>
		
	</form>
</body>
</html>