<!DOCTYPE html>
<html>
<head>
	<title>Portfolio</title>
</head>
<style type="text/css">
	*{
		margin: 0px;
	}
	body{
		background-image: url("/pics/pic1.jpg");
	}
	header{
			background-color: #ECC9C7;
			padding: 10px;
			color: black;
			text-align: center;
			font-size: 25px;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #cf7956;

	}
	.nav{
		text-decoration: none;
		font-size: 20px;
		font-family: sans-serif;
		color: #2E3047;
	}
	h1{
		text-align: center;
	}
	p{
		text-align: center;
	}
	.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}
.row::after {
  content: "";
  clear: both;
  display: table;
}
	.row{
		margin-left: 450px;
	}
	.row p{
		text-align: center;
	}


	footer{
		padding: 20px;
		margin-top: 100px;
		background-color: black;
		color: white;
		text-align: center;
	}
</style>
<body>
<header>Dreams of Jewel Joyce</header>
<br>
<nav>
	<a href="home.php" class="nav">Home</a>
	<a href="about.php" class="nav">About</a>
	<a href="contact.php" class="nav">Contact</a>
</nav>
<br>
<br>
<h1>“We Generate Fears While We Sit. We Overcome Them By Action.”</h1>
	<p>Dr. Henry Link</p>
<div class="row">
	<div class="column">
	<img src="/pics/grad.jpg">
	<p>Graduation</p>
	</div>
	<div class="column">
		<img src="/pics/it.jpg">
		<p>IT Professional</p>
	</div>
	<div class="column">
		<img src="/pics/gensur.jpg">
		<p>General Surgeon</p>
	</div>
	<div class="column">
		<img src="/pics/world.jpg">
		<p>Travel around the world</p>
	</div>
	<div class="column">
		<img src="/pics/house.jpg">
		<p>Dream House</p>
	</div>
	<div class="column">
		<img src="/pics/wedding.jpg">
		<p>Dream Wedding</p>
	</div>
</div>
<footer>Ramos &copy; 2020</footer>
</body>
</html>