<!DOCTYPE html>
<html>
<head>
	<title>Data</title>
</head>
</style>
<body>
	<header>Data Information</header>
	<br>
		Fristname: {{$dfname}}
		<br>
		Lastname: {{$dlname}}
		<br>
		Cellphone #: {{$dcp}}
		<br>
		Gender: {{$dgender}}
		<br>
		Motto: {{$dmotto}}
</body>
</html>