<!DOCTYPE html>
<html>
<head>
	<title>Portfolio</title>
</head>
<style type="text/css">
	*{
		margin: 0px;
	}
	body{
		background-image: url("/pics/pic1.jpg");
	}
	header{
			background-color: #ECC9C7;
			padding: 10px;
			color: black;
			text-align: center;
			font-size: 25px;
	}
	nav{
		text-align: center;
	}
	nav :hover{
		background-color: #cf7956;

	}
	.nav{
		text-decoration: none;
		font-size: 20px;
		font-family: sans-serif;
		color: #2E3047;
	}
	.box{
	width: 600px;
	background: rgba(0, 0, 0, 0.4);
	padding: 40px;
	text-align: center;
	margin: auto;
	margin-top: 5%;
	margin-bottom: 5%;
	color: white;
	font-family: 'Century Gothic' ,sans-serif;
}
.box-img{
	border-radius: 50%;
	width: 200px;
	height: 200px;
}

	footer{
		padding: 20px;
		background-color: black;
		margin-top: 500px;
		color: white;
		text-align: center;
	}
</style>
<body>
<header>Dreams of Jewel Joyce</header>
<br>
<nav>
	<a href="home.php" class="nav">Home</a>
	<a href="about.php" class="nav">About</a>
	<a href="contact.php" class="nav">Contact</a>
</nav>
<br>
<div class="box">
	<img src="pics/je.jpg" class="box-img">
	<p>
	Hi! Goodday! 
	<br>
	I'm Jewel Joyce Esquerra Ramos, and I am an IT students at the Urdaneta City University.
	<br>
	I always dream that one day I achieve all things that I want to achieve in my life. Like I want to become an IT expert or professional and to become a general surgeon this is my dream goal.
	<br>
	<br>
	<p>Dream High!</p>
	</p>
</div>
<footer>Ramos &copy; 2020</footer>
</body>
</html>