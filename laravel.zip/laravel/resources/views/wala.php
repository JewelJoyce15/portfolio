<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
$id=1;
$k=0;
$test = array ("Happy ")
</body>
</html>